//
//  Aperson.swift
//  ShowArchaive
//
//  Created by dehkhoda_abbas on 5/1/18.
//  Copyright © 2018 Santa Monica College. All rights reserved.
//

import Foundation

class APerson : NSObject , NSCoding
{
    var fName = ""
    var lName = ""
    var sSN = ""
   // var dateCreated = Date()
    
    required init(coder aDecoder: NSCoder) {
        fName = aDecoder.decodeObject(forKey: "fname") as! String
     //   dateCreated = aDecoder.decodeObject(forKey: "dateCreated") as! Date
        sSN = aDecoder.decodeObject(forKey: "ssn") as! String
        lName = aDecoder.decodeObject(forKey: "lname") as! String
        
      /*  valueInDollars = aDecoder.decodeInteger(forKey: "valueInDollars")*/
        
        super.init()
    }
    init(fname : String, lname : String, s : String)
    {
        fName = fname
        lName = lname
        sSN = s
        //self.dateCreated = Date()
    }
    
    func encode(with aCoder: NSCoder) {
       aCoder.encode(fName, forKey: "name")
      //  aCoder.encode(dateCreated, forKey: "dateCreated")
        aCoder.encode(lName, forKey: "lname")
        aCoder.encode(sSN, forKey: "ssn")
        
    /*    aCoder.encode(valueInDollars, forKey: "valueInDollars")
 */
 
 }
    convenience init(random: Bool = false) {
        if random {
            let fname = ["LISA", "JACK", "SUSAN"]
            let lname = ["SMITH", "BAKER", "LEE"]
            
            var idx = arc4random_uniform(UInt32(fname.count))
            let rFname = fname[Int(idx)]
            
            idx = arc4random_uniform(UInt32(fname.count))
            let rLname = lname[Int(idx)]
            
            
        
            
            let randomSerialNumber =
                UUID().uuidString.components(separatedBy: "-").first!
            
            self.init(fname: rFname,lname: rLname,s: randomSerialNumber)
            
        } else {
            self.init( fname :"",lname:  "", s : "")
        }
    }
    
    
}
