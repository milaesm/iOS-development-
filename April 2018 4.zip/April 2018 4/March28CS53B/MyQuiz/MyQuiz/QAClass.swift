//
//  QAClass.swift
//  MyQuiz
//
//  Created by dehkhoda_abbas on 2/15/17.
//  Copyright © 2017 Santa Monica College. All rights reserved.
//

import Foundation


class QAClass
{
    var arrQ = ["what is iOS","What is Square of 4"]
    
    var arrA = ["iPhone Operating System","It is 16"]
    
    var index = 0;
    
    func getQuestion() ->String {
        index = index + 1
        if index == arrA.count
        {
            index = 0
        }
        
        return arrQ[index]
    
    }
    
    func getAnswer() -> String {
        
        return arrA[index]
    }
    
    func addQ(question : String)  {
    
        arrQ.append(question);
        
    }
    
    func addA(answer : String) {
    
        arrA.append(answer)
        
    }
    
    
    
}
