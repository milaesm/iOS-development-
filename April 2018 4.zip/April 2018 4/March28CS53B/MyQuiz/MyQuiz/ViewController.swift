//
//  ViewController.swift
//  MyQuiz
//
//  Created by dehkhoda_abbas on 2/15/17.
//  Copyright © 2017 Santa Monica College. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   let m = QAClass()
    
    @IBOutlet weak var qLab: UILabel!
    
    @IBOutlet weak var aLab: UILabel!
    
    @IBAction func showQ(_ sender: UIButton) {
   
    print("You pressed Show Question")
    qLab.text = m.getQuestion()
        
    
    }
    
    @IBAction func showA(_ sender: UIButton) {
   
    print("You pressed Show Answer")
    aLab.text = m.getAnswer()
    
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        m.addQ(question: "What is 2 * 8")
        m.addA(answer: "It is 16")
        // Do any additional setup after loading the view, typically from a nib.
    }

    

}

