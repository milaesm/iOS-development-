//
//  ViewController.swift
//  SwiftShowTimeClicking
//
//  Created by dehkhoda_abbas on 11/18/15.
//  Copyright (c) 2015 Santa Monica College. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var myLab: UILabel!
    
    var timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        
   //     let runLoop = NSRunLoop.mainRunLoop()
        
   //     runLoop.addTimer(timer, forMode: NSDefaultRunLoopMode)
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func stopNow(_ sender: UIButton) {
        
        self.invalidate()
    }
    
    
    func invalidate()
    {
        timer.invalidate()
        
        
    }
    
    

    func doItNow ()
    {
       
        let todaysDate = Date()
        let dateFormatter = DateFormatter()
        
   
       
        dateFormatter.dateFormat = "h:m:s"
       
       // dateFormatter.stringFromDate(todaysDate)
        
        
       // dateFormatter.dateStyle = NSDateFormatterMediumStyle
        
        
        let DateInFormat = dateFormatter.string(from: todaysDate)

      // println("\(DateInFormat)")
        
        myLab.text = DateInFormat
        

        
       
        
        
        
         
        
        
        
        
        
            }
    
    
    
    
    
    @IBAction func display(_ sender: UIButton) {
        
    timer = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(ViewController.doItNow), userInfo: nil, repeats: true)
        
        
        
     //   [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
        
    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

