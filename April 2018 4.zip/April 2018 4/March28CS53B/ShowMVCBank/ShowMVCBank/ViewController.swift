//
//  ViewController.swift
//  ShowMVCBank
//
//  Created by dehkhoda_abbas on 3/28/18.
//  Copyright © 2018 Santa Monica College. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let theDice = Dice()
        let myBank = Bank(amount: 500.0)
        
        
        print("===>>>\(myBank.getBalance())")
        theDice.throwDice()
        print("\(theDice.description())")
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

