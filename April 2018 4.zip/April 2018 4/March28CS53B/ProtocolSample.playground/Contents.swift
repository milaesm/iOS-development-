//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//  Protocol as type

protocol Walkable
{
    var name : String { get set }
    
    func walk( numberOfStep: Int)
    
}

// human, animals robots can walk

class Human:Walkable
{
   var name = "john"
    
    func walk(numberOfStep: Int)
    {
        print("human is walking \(numberOfStep)")
        
    }

}

class Dog : Walkable
{
   var name = "GoodDog"
    
    func walk(numberOfStep: Int) {
        print("Dog is walking \(numberOfStep)")
    }
    
    func sound()
    {
        print("Voff   Vofff\n")
    }
    
}



class Cat : Walkable
{
    var name = "CCCTY"
    
        
    func test()
    {
        print("huhuhuhu");
    }
    

    
    func walk(numberOfStep: Int) {
        print("Cat is walking \(numberOfStep) Steps")
    }
}
// this is global function

func runWalker( walker  : Walkable)
{
  if let xx = walker as? Cat
  {
        xx.test()
   }
    else if let dd = walker as? Dog
    {
        dd.sound()
    }else
    {
       walker.walk(numberOfStep: 20)
    }
}

var x = Human()

runWalker(walker: x)

var xx = Cat()
xx.walk(numberOfStep: 40)
runWalker(walker: xx)

let d = Dog()
runWalker(walker: d)
d.walk(numberOfStep: 50)


