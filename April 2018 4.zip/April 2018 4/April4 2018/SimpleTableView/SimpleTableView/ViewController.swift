//
//  ViewController.swift
//  SimpleTableView
//
//  Created by dehkhoda_abbas on 4/4/18.
//  Copyright © 2018 Santa Monica College. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    let names = ["Lisa","Jack","Susan","Tom","happy","Student","work","Test","Stress"]
    
    let simpleIdentifier = "SimpleTableIdentifier"
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: simpleIdentifier)
        if (cell == nil)
        {
            cell = UITableViewCell(style: .value1, reuseIdentifier: simpleIdentifier)
        }
        let image = UIImage(named: "N.png")
        cell?.imageView?.image = image
       // let highlightedImage = UIImage(named :"N.png")
       // cell?.imageView?.highlightedImage = highlightedImage
        
        if indexPath.row < 4
        {
           cell?.detailTextLabel?.text = "Mr Wonderfull"
        }else
        {
            cell?.detailTextLabel?.text = "Good Student"
        }
        
        
        
        
        cell?.textLabel?.text = "Row=\(indexPath.row), section=\(indexPath.section)"
      //  cell?.textLabel?.text = names[indexPath.row]
      //  cell?.textLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    
        return indexPath.row == 0 ? 100 : 70
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

