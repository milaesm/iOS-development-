//
//  ViewController.swift
//  ShowAPersonClass
//
//  Created by B203u on 3/28/18.
//  Copyright © 2018 B203u. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    let pLisa = APerson(fName: "Lisa", lName: "Smith", sSN: "111-11-111", age: 21, heightInInches: 65)
    
    let pJack = APerson(fName: "Jack", lName: "Smith", sSN: "222-22-2222", age: 45, heightInInches: 75)
    
    let tom = APerson(fName: "Tom", lName: "Cruise", sSN: "333-33-3333", age: 48, heightInInches: 67)
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("\(pLisa.showAPesron())")
        
        
        pLisa.marriedTo(ap: pJack)
        
        
        
        
        
        pJack.divorceFrom(ap: pLisa)
       // print("\(pJack.showAPesron()")       tom.marriedTo(ap: pLisa)
        print("\(tom.showAPesron())")
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

