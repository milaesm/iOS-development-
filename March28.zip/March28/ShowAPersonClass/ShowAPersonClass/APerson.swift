//
//  APerson.swift
//  ShowAPersonClass
//
//  Created by B203u on 3/28/18.
//  Copyright © 2018 B203u. All rights reserved.
//

import Foundation

class APerson : Driver
{
    // define and initialize member or properties
    
    private var fName : String = "No First Name"
    private var lName : String = "No Last Name"
    private var age : Int = 0
    private var sSN : String = "No SSN number"
    private var howTallInInches = 65
    
    //compute properties65
    
    private var hw : APerson?
    
    private var howTall : String
    {
        if(howTallInInches >= 72)
        {
            return "Tall"
        }
        else if (howTallInInches >= 65)
        {
            return "Mediam"
            
        }
        else{
            return "Short"
        }
        
    }
    
    // designated init
    
    init( fName : String , lName : String, sSN : String, age : Int, heightInInches : Int)
    {
        self.fName = fName
        self.lName = lName
        self.sSN  = sSN
        self.age = age
        self.howTallInInches = heightInInches
        
        
    }
    
    //Convenience
    
    convenience init(fName : String, lName : String, sSN : String)
    {
        
        self.init(fName : fName, lName : lName , sSN : sSN, age : 0, heightInInches : 0)
    }
    
    
    func isMarried() -> Bool
    {
        if hw != nil
        {
            return true
        }
        else
        {
            return false
        }
      // return hw != nil
        
    }
    
    func marriedTo(ap : APerson)
    {
        if self.isMarried() || ap.isMarried()
        {
            print("Already married")
        }
        else
        {
            self.hw = ap
            ap.hw = self
            
        }
        
    }
    
    func divorceFrom( ap : APerson)
    {
        if self.hw === ap
        {
            self.hw = nil
            ap.hw = nil
            
        }
    }
    
    func drivingSkill() -> String {
        if self.isMarried()
        {
            return " Drives Carefully"
        }
        else
        {
            return "Drives Recklessly"
        }
    }
    
    
    func setFName (fName : String)
    {
        self.fName = fName
    }
    func getFName() -> String
    {
        return fName
    }
    
    func setLName (lName : String)
    {
        self.lName = lName
    }
    func getLName() -> String
    {
        return lName
    }
    
    func setSSN (sSN : String)
    {
        self.sSN = sSN
    }
    func getSSN() -> String
    {
        return sSN
    }
    
    func setAge( age : Int)
    {
        self.age = age
    }
    func getAge()->Int
    {
        return age
    }
    
    func setHeightInInches( heightInInches : Int)
    {
        self.howTallInInches = heightInInches
    }
    func getHeightInInches()->Int
    {
        return howTallInInches    }
   
    
    func showAPesron()->String
    {
        
        
        
        return "First Name :\(fName)\nLast Name:\(lName)\nSSN:\(sSN)\nAge:\(age)\nHeightInInches:\(setHeightInInches)\nHow Tall:\(howTall)\nDriving Skill\(drivingSkill())\n"
    }
    
    
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

