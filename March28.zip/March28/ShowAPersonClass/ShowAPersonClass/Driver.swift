//
//  Driver.swift
//  ShowAPersonClass
//
//  Created by B203u on 3/28/18.
//  Copyright © 2018 B203u. All rights reserved.
//

import Foundation

protocol Driver
{
    
    func drivingSkill() -> String
    
    
}
