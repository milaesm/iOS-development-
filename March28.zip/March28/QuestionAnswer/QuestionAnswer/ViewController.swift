//
//  ViewController.swift
//  QuestionAnswer
//
//  Created by B203u on 3/28/18.
//  Copyright © 2018 B203u. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var myQA = QA()
    
    @IBOutlet weak var qLab: UILabel!
    
    @IBOutlet weak var aLab: UILabel!
    
    @IBAction func showQuestion(_ sender: UIButton) {
    
    qLab.text = myQA.getQ()
    
    }
    
    @IBAction func showAnswer(_ sender: UIButton) {
    
    aLab.text = myQA.getAns()
    
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      myQA.addQ(question: "What is 5 + 2")
      myQA.addAns(answer: "It is 7")
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

