//
//  QA.swift
//  QuestionAnswer
//
//  Created by B203u on 3/28/18.
//  Copyright © 2018 B203u. All rights reserved.
//

import Foundation

class QA
{
   var arrQ = ["What is iOS","What is capital of California","What is 4 + 6?","What is SQuare of 4"]
   var arrAns = ["Iphone OS","Sacremento","is 10","answer 2"]

    var index = 0
    
    func getQ() -> String {
        index += 1
        if( index == arrAns.count)
        {
            index = 0
        }
        return arrQ[index]
        
    }
    func getAns() -> String {
        
        
        return arrAns[index]
    }
    func addQ(question : String) {
       arrQ.append(question)
        
    }
    func addAns(answer : String) {
    
       arrAns.append(answer)
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
