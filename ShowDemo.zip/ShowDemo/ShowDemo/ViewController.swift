//
//  ViewController.swift
//  ShowDemo
//
//  Created by B203u on 2/14/18.
//  Copyright © 2018 B203. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var count = 0
    
    @IBOutlet weak var flipCount: UILabel!
    
    func flipCards(withEmoji emoji : String, on button : UIButton)
    {
        if button.currentTitle == emoji
        {
           button.setTitle("", for: .normal)
           button.backgroundColor = #colorLiteral(red: 1, green: 0.5781051517, blue: 0, alpha: 1)
            
        }else
        {
            button.setTitle(emoji, for: .normal)
            button.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            
        }
        
        
        
    }
    
    @IBAction func touchCard(_ sender: UIButton) {
       //print("It is working")
        count += 1
        
      flipCards(withEmoji: "👻", on: sender)
        flipCount.text = "FlipCount:\(count)"
    }
    

}

