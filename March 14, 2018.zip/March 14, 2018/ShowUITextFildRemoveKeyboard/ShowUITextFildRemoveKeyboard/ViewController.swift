//
//  ViewController.swift
//  ShowUITextFildRemoveKeyboard
//
//  Created by B203u on 3/14/18.
//  Copyright © 2018 B203u. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITextFieldDelegate {

    @IBOutlet weak var t1: UITextField!
    
    
    
    
    @IBOutlet weak var t2: UITextField!
    
    
    @IBOutlet weak var t3: UITextField!
    
    @IBAction func t3(_ sender: UITextField) {
    
    let num1 = Int(t1.text!)
    let num2 = Int(t2.text!)
    let sum = num1! + num2!
    t3.text = "Total is \(sum)"
    
    }
    
     func textFieldShouldReturn(_ textField: UITextField) -> Bool
     {
        textField.resignFirstResponder()
        return true
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        t3.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

