//
//  CircleView.swift
//  ShowTabUIcontroller
//
//  Created by B203u on 3/14/18.
//  Copyright © 2018 B203u. All rights reserved.
//

import UIKit

class CircleView: UIView {

    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    
     let path = UIBezierPath()
    
     path.lineWidth = 25
     UIColor.green.setStroke()
     UIColor.blue.setFill()
        
     let radius = self.bounds.width / 4
    
     path.addArc(withCenter: center, radius: radius, startAngle: CGFloat(0.0), endAngle: CGFloat( .pi * 2.0 ), clockwise: true)
        path.stroke()
        path.fill()
        path.close()
        
        
        
        
    
    
    
    }
    

}
