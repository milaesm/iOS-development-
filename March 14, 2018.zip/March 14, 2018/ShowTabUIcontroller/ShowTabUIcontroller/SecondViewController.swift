//
//  SecondViewController.swift
//  ShowTabUIcontroller
//
//  Created by B203u on 3/14/18.
//  Copyright © 2018 B203u. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    let myCircle = CircleView()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myCircle.setNeedsDisplay()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        
        // Dispose of any resources that can be recreated.
    }


}

