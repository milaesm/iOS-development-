//
//  AttractionViewCellTableViewCell.swift
//  TableViewStory
//
//  Created by dehkhoda_abbas on 4/18/18.
//  Copyright © 2018 Santa Monica College. All rights reserved.
//

import UIKit

class AttractionViewCellTableViewCell: UITableViewCell {

    @IBOutlet weak var attLabel: UILabel!
    
    @IBOutlet weak var attImage: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
